<?php
?>
<ul class="tabs-coordinacion">
    <li id="mun" class="selected"><a id="mun" href="#municipal" class="ver-lista-investigaciones-feria" name="municipal" rel="nofollow">Ferias Municipales</a></li>
    <li id="dptal"><a href="#departamental" id="dptal" class="ver-lista-investigaciones-feria" name="departamental" title="" rel="nofollow">Ferias Departamentales</a></li>
</ul>
<div id="ajax-investigaciones0">
</div>