<!-- 
Se Muestra el Mensaje de Bienvenida al Plugin
@author DIEGOX_CORTEX
-->

<h1>
<?php 
    echo $vars['name'];
?>
</h1>

<h1>Bienvenido a la gestion de las lineas tematicas</h1>

