<?php

/**
 * Formulario para crear una Línea Temática
 * @author DIEGOX_CORTEX
 */


//$instructions = elgg_echo('help:admin:instruct');


$nombre_input = elgg_view('input/text', array(
    'name' => 'nombre',
    'required' => 'true',
    'placeholder' => 'Nombre de la Linea Tematica'
        ));

$tipo_input = elgg_view('input/radio', array('options' => array('Proyectos abiertos' => 'Proyectos abiertos', 
                                                                'Proyectos preestructurados' => 'Proyectos preestructurados', 
                                                                'Proyectos abiertos y preestructurados'=>'Proyectos abiertos y preestructurados'), 
                                              'name' => 'proyectos',));
$cancel = elgg_get_site_url().'linea/listar';
$descripcion = elgg_view('input/longtext', array('name' => 'descripcion', 'placeholder' => 'Descripción de la Linea Tematica'));
$button = elgg_view('input/submit', array(
    'value' => elgg_echo('Registrar')
 ));


?>
<div class="content-coordinacion">
        <div class="titulo-coordinacion">
            <h2>Registrar Linea Temática</h2>
        </div>

    
<?php
echo <<<HTML


<div>
        <label>Nombre de la línea: </label><br />$nombre_input<br/>
        <label>Tipo: </label><br />$tipo_input<br/>
        <label>Descripción: </label><br />$descripcion<br/>
</div>
<div class="elgg-foot">
        $button
        <a href='$cancel' class='link-button'>Cancelar</a>
</div>
HTML;
?>

</div>