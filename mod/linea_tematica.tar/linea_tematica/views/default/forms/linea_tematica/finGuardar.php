<!-- 
 Donde se redirecciona luego de almacenar
@author DIEGOX_CORTEX
-->

<?php 
    
echo 'Se Pudo';

?>


