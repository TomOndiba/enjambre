<?php

/**
 * Action que registra una Línea Temática
 * @author DIEGOX_CORTEX
 */
$nombre = get_input('nombre');
$desc = get_input('descripcion');
$tipo = get_input('proyectos');
if (!elgg_existe_linea($nombre)) {
    $tematica = new ElggLineaTematica();
    $tematica->name = $nombre;
    $tematica->description = $desc;
    if($tipo == "Proyectos abiertos y preestructurados"){
        $tipo = "Mixta";
    }
    $tematica->tipo = $tipo;
    $guid = $tematica->save();
    if (!$guid) {
        register_error(elgg_echo("error:existe:linea:create"), 'error');
        forward(REFERER);
    } else {
        system_message(elgg_echo("okay:linea:create"), 'success');
        forward('/linea/listar');
    }
} else {
    register_error(elgg_echo("error:existela:linea:create"), 'error');
    forward(REFERER);
}