<?php

$guid_convocatoria= $vars['guid_convocatoria'];
echo elgg_get_view_asesores_no_asignados_convocatoria($guid_convocatoria);