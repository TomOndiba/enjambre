<?php

$guid_convocatoria = $vars['guid_convocatoria'];
echo elgg_get_evaluadores_preinscritos($guid_convocatoria);
?>