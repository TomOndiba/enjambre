<?php

$guid_convocatoria= $vars['guid_convocatoria'];
echo elgg_get_evaluadores_convocatoria($guid_convocatoria);
?>