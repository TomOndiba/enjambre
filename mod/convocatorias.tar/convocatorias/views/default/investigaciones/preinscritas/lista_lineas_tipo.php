<?php   

echo <<<HTML

<div id="display1">
</div>  
HTML;
?>