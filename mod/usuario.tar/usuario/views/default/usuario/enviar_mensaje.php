<div style="width: 600px; margin:0 auto;">
    <div style="width: 600px; height: 100px;">
        <img src="http://enjambre.co/imagenes/email/cabezote.png" style="width: 600px; height: 100px"/>
    </div>
    <div style="width: 400px; margin-left: 100">
        <?php echo $vars['mensaje'];?>
    </div>
</div>