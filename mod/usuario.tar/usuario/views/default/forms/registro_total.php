<?php

$button = elgg_view('input/submit', array('id' => 'Agregar', 'value' => elgg_echo('Aceptar')));

echo $file_input.$button;