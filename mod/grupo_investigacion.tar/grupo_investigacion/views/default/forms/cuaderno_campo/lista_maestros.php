<?php

echo <<<HTML

<div id="display2">
</div>  
HTML;
?>