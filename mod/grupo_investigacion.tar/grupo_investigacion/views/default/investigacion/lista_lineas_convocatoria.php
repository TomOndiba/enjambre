<?php   

echo <<<HTML

<div id="display">
</div>  
HTML;
?>