

.item-list-grupos-left{
    display:inline-block;
}

.lista-grupos-instituciones{
    margin:25px;
}
.item-list-grupos-left{
    padding:10px;
}

.item-list-grupos-left:hover{
    background:#e5e5e5;
}

.tittle-box{

}
