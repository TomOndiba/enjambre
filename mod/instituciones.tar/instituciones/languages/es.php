<?php

$espa = array(
    'error:existe:institucion:create' => 'La institucion ya existe',
    'ok:institucion:create' => 'La institución ha sido creada',
    'help:admin:instruct'=>'Por favor, diligencie el siguiente formulario para registrar una institución.',
    'institucion:ok:delete'=>'La Institución ha sido eliminada',
    'institucion:error:delete'=>'No se puede elimnar la institución',
    'ok:institucion:update'=>'La Institución se actualizó correctamente'
);

add_translation('es', $espa);


