<?php
$guid_inv = get_input("guid_inv");
$investigacion=new ElggInvestigacion($guid_inv);
$grupo=$investigacion->getEntitiesFromRelationship("tiene_la_investigacion", true);

//$grupo = elgg_get_relationship_inversa($investigacion, "tiene_la_investigacion")[0];
$vars = array('grupo' => $grupo[0]->guid, 'investigacion' => $guid_inv);
$bitacora4 = elgg_view('bitacoras/bitacora4/bitacora4', $vars);
$bitacora5=elgg_view('bitacoras/bitacora5/bitacora5', $vars);
$bitacora51= elgg_view('bitacoras/bitacora5_1/bitacora5_1', $vars);
$bitacora52= elgg_view('bitacoras/bitacora5_2/bitacora5_2', $vars);
?>
<div class="menu-bitacoras-etapa-2">
    <ul>
        <li id="bitacora-4">Bitácora 4</li>
        <li id="bitacora-5">Bitácora 5</li>
        <li id="bitacora-51">Bitácora 5.1</li>
        <li id="bitacora-52">Bitácora 5.2</li>
    </ul>
</div>
<div class="bitacoras-etapa-2">
    <div id="bitacora4" class="bitacora-etapa-2">
        <?php echo $bitacora4; ?>
    </div>
    <div id="bitacora5" class="bitacora-etapa-2">
        <?php echo $bitacora5; ?>
    </div>
    <div id="bitacora51" class="bitacora-etapa-2">
        <?php echo $bitacora51;?>
    </div>
    <div id="bitacora52" class="bitacora-etapa-2">
        <?php echo $bitacora52;?>
    </div>
</div>