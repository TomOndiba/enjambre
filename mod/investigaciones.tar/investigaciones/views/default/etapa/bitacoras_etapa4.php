<?php
$guid_inv = get_input("guid_inv");
$investigacion = new ElggInvestigacion($guid_inv);
$grupo = $investigacion->getEntitiesFromRelationship("tiene_la_investigacion", true);

$user=elgg_get_logged_in_user_guid();

$entities = elgg_get_entities_from_relationship(array(
    'relationship' => 'tiene_la_bitacora',
    'relationship_guid' => $guid_inv,
        ));




$vars = array('grupo' => $grupo[0]->guid, 'investigacion' => $guid_inv);
$bitacora8 = elgg_view('bitacoras/bitacora8/bitacora8', $vars);
$bitacora9 = elgg_view('bitacoras/bitacora9/bitacora9', $vars);

?>
<div class="menu-bitacoras-etapa-2">
    <ul>
        <li id="bitacora-4">Bitácora 8</li>
        <li id="bitacora-5">Bitácora 9</li>

    </ul>
</div>
<div class="bitacoras-etapa-2">
    <div id="bitacora4" class="bitacora-etapa-2">
    <?php echo $bitacora8; ?>
    </div>
    <div id="bitacora5" class="bitacora-etapa-2">
        <?php echo $bitacora9; ?>
    </div>
   
</div>