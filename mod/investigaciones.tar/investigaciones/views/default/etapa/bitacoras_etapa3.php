<?php
$guid_inv = get_input("guid_inv");
$investigacion = new ElggInvestigacion($guid_inv);
$grupo = $investigacion->getEntitiesFromRelationship("tiene_la_investigacion", true);

$user=elgg_get_logged_in_user_guid();

$entities = elgg_get_entities_from_relationship(array(
    'relationship' => 'tiene_la_bitacora',
    'relationship_guid' => $guid_inv,
        ));



if($user==$investigacion->owner_guid){
    
$vars1 = bitacoras_prepare_form_b6_vars(null, $user, null, $guid_inv, $grupo->guid);
$vars2 = bitacoras_prepare_form_b61_vars(null,$user, null, $guid_inv, $grupo->guid);
$vars3 = bitacoras_prepare_form_b62_vars(null,$user, null, $guid_inv, $grupo->guid);

$bitacora6 = elgg_view_form('bitacoras/edit', array(), $vars1);
$bitacora61 = elgg_view_form('bitacoras/edit', array(), $vars2);
$bitacora62 = elgg_view_form('bitacoras/edit', array(), $vars3);

}
else{
    
$bitacora6 = "<div class='msj-no-componentes'> La Bitácora 6 aún no ha sido creada</div>";
$bitacora61 ="<div class='msj-no-componentes'>La Bitácora 6.1 aún no ha sido creada </div>";
$bitacora62 ="<div class='msj-no-componentes'>La Bitácora 6.2 aún no ha sido creada</div>";
}


foreach ($entities as $entity) {


    if ($entity->description == '6') {
        
        $bitacora6 = elgg_view_entity($entity, array('full_view' => true));
    } else if ($entity->description == '6.1') {
        $bitacora61 = elgg_view_entity($entity, array('full_view' => true));
       
    } else if ($entity->description == '6.2') {
        $bitacora62 = elgg_view_entity($entity, array('full_view' => true));
        
    }
}



$vars = array('grupo' => $grupo[0]->guid, 'investigacion' => $guid_inv);
$bitacora7 = elgg_view('bitacoras/bitacora7/bitacora7', $vars);
?>
<div class="menu-bitacoras-etapa-2">
    <ul>
        <li id="bitacora-4">Bitácora 6</li>
        <li id="bitacora-5">Bitácora 6.1</li>
        <li id="bitacora-51">Bitácora 6.2</li>
        <li id="bitacora-52">Bitácora 7</li>
    </ul>
</div>
<div class="bitacoras-etapa-2">
    <div id="bitacora4" class="bitacora-etapa-2">
<?php echo $bitacora6; ?>
    </div>
    <div id="bitacora5" class="bitacora-etapa-2">
        <?php echo $bitacora61; ?>
    </div>
    <div id="bitacora51" class="bitacora-etapa-2">
        <?php echo $bitacora62; ?>
    </div>
    <div id="bitacora52" class="bitacora-etapa-2">
        <?php echo $bitacora7; ?>
    </div>
</div>