<?php

$esp = array(
    'nota:save:ok'=> 'La Nota se Agregó con éxito',
    'nota:save:error' => 'No se pudo registrar la Nota',
   
);

add_translation('es', $esp);

