<?php

$bitacora = new BitacoraTres(get_input('id_bitacora'));
$bitacora->campo1 = get_input('campo_uno');
$bitacora->campo2 = get_input('campo_dos');
$bitacora->campo3 = get_input('campo_tres');
$bitacora->save();
forward(REFERER);