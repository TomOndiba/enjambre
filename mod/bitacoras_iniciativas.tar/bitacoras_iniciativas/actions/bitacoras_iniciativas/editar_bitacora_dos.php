<?php

$bitacora = new BitacoraDos(get_input('id_bitacora'));
$bitacora->sintesis = get_input('sintesis');
$bitacora->reflexion = get_input('reflexion');
$bitacora->discusion = get_input('discusion');
$bitacora->pregunta = get_input("pregunta");
for ($i = 0; $i < 6; $i++) {
    $pregunta = "p{$i}";
    $sintesis = "p{$i}s";
    $fuente = "p{$i}f";
    $val_p = get_input($pregunta);
    $val_s = get_input($sintesis);
    $val_f = get_input($fuente);
    if ($val_p) {
        $bitacora->$pregunta = $val_p;
    }
    if ($val_s) {
        $bitacora->$sintesis = $val_s;
    }if($val_f) {
        $bitacora->$fuente = $val_f;
    }
}
$bitacora->save();
forward(REFERER);
