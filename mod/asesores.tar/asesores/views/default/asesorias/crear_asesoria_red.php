<?php

$params = array("red" => get_input("red"));
$content = elgg_view_form('asesorias_red/crear_dia_asesoria', null, $params);
echo $content;


