<?php
/**
 * formualrio donde se gestiona la informacion de la bitacora 7
 * @author DIEGOX_CORTEX
 */
$id_inv = $vars['id_inv'];
$owner_inv = $vars['owner_inv'];
$bit = $vars['info_bit'];
$guid_bit = $vars['bit'];
$nombre_institucion = $vars['nombre_institucion'];
$municipio = $vars['municipio'];
$nombre_grupo = $vars['nombre_grupo'];
$nombre_inv = $vars['nombre_inv'];
$docente = $vars['docente'];
$asesor = $vars['asesor'];

$url1 = elgg_get_site_url() . "action/bitacoras/print?id=" . $id_inv . '&bit=101';
$ver_formato = elgg_add_action_tokens_to_url($url1);

if (!empty($bit['aspectos'])) {
    $guid_archivo = $bit['archivo'];
    $url_descarga = "<lable>Ya ha subido un archivo</lable><br><a href='" . elgg_get_site_url() . "file/download/{$guid_archivo}'>Descargar</a>";
    $aspectos = $bit['aspectos'];
    $capacidades = $bit['capacidades'];
    $cambios = $bit['cambios'];
    $caracteristicas = $bit['caracteristicas'];
}
?>

<div class="form-nuevo-album">

    <input type="hidden" value="<?php echo $guid_bit?>" name="guid_bit">

    <h2 class="title-legend">
        <center>BITACORA Nº 7. REFLEXION DE LA ONDA</center>
    </h2>
    <br>
    <table class="tabla-integrantes">
        <tr>
            <th>Nombre del grupo investigador:</th>
            <td><?php echo $nombre_grupo; ?></td>
        </tr>
        <tr>
            <th>Problema de investigación:</th>
            <td><?php echo $nombre_inv; ?></td>
        </tr>
        <tr>
            <th>Docente Coinvestigador:</th>
            <td><?php echo $docente; ?></td>
        </tr>
        <tr>
            <th>Nombre del asesor:</th>
            <td><?php echo $asesor; ?></td>
        </tr>
        <tr>
            <th>Institución Educativa:</th>
            <td><?php echo $nombre_institucion; ?></td>
        </tr>
        <tr>
            <th>Municipio:</th>
            <td><?php echo $municipio; ?></td>
        </tr>
    </table>
    <br>
    <h3 style="color: #000000; font-size: 14pt; align:center">Actividades a realizar</h3>
    <h3 style="color: #000000; font-size: 12pt; alignment-adjust: central">1.	Barrido de los instrumentos y de las herramientas de investigación</h3>
    <br>
    <?php echo elgg_echo('bitacora7:actividades'); ?>
    <br>
    <table>
        <tr>
            <th bgcolor="#FAA803" colspan="3">Fase 1.  Convocatoria y acompañamiento a la conformación del grupo, la formulación de las preguntas y el planteamiento del problema</th>
        </tr>
        <tr>
            <td>Barrido de los instrumentos de registro</td>
            <td>Barrido de las herramientas de investigación</td>
            <td>Anotaciones sobre los hallazgos y los aspectos que el grupo considere importantes resaltar</td>
        </tr>               
    </table>    
    <br>
    <table>
        <tr>
            <th bgcolor="#CE9AD0" colspan="3">Fase 2.  Diseño y recorrido de las trayectorias de indagación</th>
        </tr>
        <tr>
            <td>Barrido de los instrumentos de registro</td>
            <td>Barrido de las herramientas de investigación</td>
            <td>Anotaciones sobre los hallazgos y los aspectos que el grupo considere importantes resaltar</td>
        </tr>               
    </table>
    <br>
    <table>
        <tr>
            <th bgcolor="#8E8EFB" colspan="3">Fase 3. Reflexión, propagación de las Ondas y construcción de la Comunidad Enjambre.</th>
        </tr>
        <tr>
            <td>Barrido de los instrumentos de registro</td>
            <td>Barrido de las herramientas de investigación</td>
            <td>Anotaciones sobre los hallazgos y los aspectos que el grupo considere importantes resaltar</td>
        </tr>               
    </table>
    <br>
    <?php echo elgg_echo('bitacora7:actividades2'); ?>
    <br>

    <br>
    <h3 style="color: #000000; font-size: 12pt; alignment-adjust: central">2.	Composición del informe de investigación:  Escrito que resume el problema de investigación, las metas, la metodología, los resultados y las conclusiones</h3>
    <a class="" href="<?php echo $ver_formato; ?>">Ver Formato</a>
    <br><br>
    <h3 style="color: #000000; font-size: 12pt; alignment-adjust: central">3.	Ejecución de los recursos asignados por el Proyecto Enjambre a nuestro grupo de investigación.</h3><br>

    <?php echo elgg_echo('bitacora7:actividades3'); ?>
    <br>
    <?php echo elgg_echo('bitacora7:actividades3_1'); ?>

    <br><br>
    <h3 style="color: #000000; font-size: 14pt; alignment-adjust: central">REGISTRO DE SISTEMATIZACIÓN/ PARA EL MAESTRO ACOMPAÑANTE</h3>

    <div>
        <label>• Enuncie los tres aspectos que más le asombraron y le sirven para incorporar en su práctica de maestro en esta  etapa de la reflexión de la Onda.</label>
        <textarea name="aspectos" placeholder="Diligencie este campo..." required="true"><?php echo $aspectos; ?></textarea>
    </div>    
   
    <div>
        <label>• ¿cuáles serían las principales capacidades que desarrollan los niños, las niñas y los jóvenes en esta etapa del Proyecto Enjambre?</label>
        <textarea name="capacidades" placeholder="Diligencie este campo..." required="true"><?php echo $capacidades; ?></textarea>
    </div>
   
    <div>
        <label>• Como maestro o maestra En el Proyecto Enjambre, señale los principales cambios que deben realizarse en la cultura escolar para que la investigación se convierta en una estrategia pedagógica.</label>
        <textarea name="cambios" placeholder="Diligencie este campo..." required="true"><?php echo $cambios; ?></textarea>
    </div>
 
    <div>
        <label>• ¿Cuáles serían las características de la indagación (tres últimas etapas) que practican los maestros en el Proyecto Enjambre?.  </label>
        <textarea name="caracteristicas" placeholder="Diligencie este campo..." required="true"><?php echo $caracteristicas; ?></textarea>
    </div>
 
    <div>
        <?php echo $url_descarga; ?><br>
        <label>Subir el Archivo de Reflexión de la Onda</label>
        <label class="lbl-button">
            <span>Seleccione aquí la imagen</span> <input type="file" name="archivo">
        </label>
       
    </div>

    <input type="submit" value="Guardar">
</div>