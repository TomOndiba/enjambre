<?php
/**
 * formualrio donde se gestiona la informacion de la bitacora 9
 * @author DIEGOX_CORTEX
 */
$id_inv = $vars['id_inv'];
$owner_inv = $vars['owner_inv'];
$bit = $vars['info_bit'];
$guid_bit = $vars['bit'];
$nombre_institucion = $vars['nombre_institucion'];
$municipio = $vars['municipio'];
$nombre_grupo = $vars['nombre_grupo'];
$nombre_inv = $vars['nombre_inv'];
$docente = $vars['docente'];
$asesor = $vars['asesor'];
?>

<div class="form-nuevo-album">

    <input type="hidden" value="<?php echo $guid_bit ?>" name="guid_bit">

    <h2 class="title-legend">
        <center>
            BITACORA Nº 9. COMUNIDADES DE SABER, REDES Y LINEAS TEMATICAS
        </center>
    </h2>
    <br>
    <table class="tabla-integrantes">
        <tr>
            <th>Nombre del grupo investigador:</th>
            <td><?php echo $nombre_grupo; ?></td>
        </tr>
        <tr>
            <th>Problema de investigación:</th>
            <td><?php echo $nombre_inv; ?></td>
        </tr>
        <tr>
            <th>Docente Coinvestigador:</th>
            <td><?php echo $docente; ?></td>
        </tr>
        <tr>
            <th>Nombre del asesor:</th>
            <td><?php echo $asesor; ?></td>
        </tr>
        <tr>
            <th>Institución Educativa:</th>
            <td><?php echo $nombre_institucion; ?></td>
        </tr>
        <tr>
            <th>Municipio:</th>
            <td><?php echo $municipio; ?></td>
        </tr>
    </table>
    <br>
    <h3 style="color: #000000; font-size: 14pt">Actividades a realizar</h3>
    <div>
        <h3 style="color: #000000; font-size: 12pt">1.	Describir qué tipo de comunidades de saber o redes se lograron a través de la ejecución de la investigación, mencionarlas  y ampliar el cómo se hicieron posibles y qué aportes o apoyos obtuvieron de las mismas.</h3>
        <textarea name="comunidades" placeholder="Diligencie este campo..." ><?php echo $bit['comunidades'];?></textarea>
    </div>

    <h3 style="color: #000000; font-size: 14pt">REGISTRO DE SISTEMATIZACIÓN/ PARA EL MAESTRO ACOMPAÑANTE</h3>
    <div>
        <label>1.	¿Cuáles serían las características del espíritu científico que se fomenta en el tipo de organización que propone el Proyecto Enjambre (grupos, líneas, redes y comunidades)? Enumérelas.</label>
        <textarea name="caracteristicas" placeholder="Diligencie este campo..."><?php echo $bit['caracteristicas'];?></textarea>
    </div>   
    <div>
        <label>2.	¿De qué manera la organización de líneas temáticas, redes y comunidades favorece el desarrollo de estas capacidades: sociales, cognitivas, comunicativas y científicas y cómo se manifiestan en los miembros del grupo?.</label>
        <textarea name="organizacion" placeholder="Diligencie este campo..."><?php echo $bit['organizacion'];?></textarea>
    </div>  
    <input type="submit" value="Guardar">
</div>