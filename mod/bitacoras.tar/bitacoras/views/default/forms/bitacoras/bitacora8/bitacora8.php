<?php
/**
 * formualrio donde se gestiona la informacion de la bitacora 8
 * @author DIEGOX_CORTEX
 */
$id_inv = $vars['id_inv'];
$owner_inv = $vars['owner_inv'];
$bit = $vars['info_bit'];
$guid_bit = $vars['bit'];
$nombre_institucion = $vars['nombre_institucion'];
$municipio = $vars['municipio'];
$nombre_grupo = $vars['nombre_grupo'];
$nombre_inv = $vars['nombre_inv'];
$docente = $vars['docente'];
$asesor = $vars['asesor'];

if (!empty($bit['ensayo'])) {
    $guid_archivo = $bit['archivo'];
    $url_descarga = "<lable>YA ha subido un archivo</lable><br><a href='" . elgg_get_site_url() . "file/download/{$guid_archivo}'>Descargar</a>";
    $ensayo = $bit['ensayo'];
}
?>

<div class="form-nuevo-album">

    <input type="hidden" value="<?php echo $guid_bit ?>" name="guid_bit">

    <h2 class="title-legend">
        <center>BITACORA Nº 8. LA PROPAGACION DE LA ONDA
        </center>
    </h2>
    <br>
    <table class="tabla-integrantes">
        <tr>
            <th>Nombre del grupo investigador:</th>
            <td><?php echo $nombre_grupo; ?></td>
        </tr>
        <tr>
            <th>Problema de investigación:</th>
            <td><?php echo $nombre_inv; ?></td>
        </tr>
        <tr>
            <th>Docente Coinvestigador:</th>
            <td><?php echo $docente; ?></td>
        </tr>
        <tr>
            <th>Nombre del asesor:</th>
            <td><?php echo $asesor; ?></td>
        </tr>
        <tr>
            <th>Institución Educativa:</th>
            <td><?php echo $nombre_institucion; ?></td>
        </tr>
        <tr>
            <th>Municipio:</th>
            <td><?php echo $municipio; ?></td>
        </tr>
    </table>
    <br>
    <h3 style="color: #000000; font-size: 14pt; align:center">Actividades a realizar</h3>
    <h3 style="color: #000000; font-size: 12pt; alignment-adjust: central">1.	Definir los espacios o escenarios para la propagación</h3><br>

    <?php echo elgg_echo('bitacora8:actividades'); ?>
    <br>
    <h3 style="color: #000000; font-size: 12pt; alignment-adjust: central">Registre en las siguientes tablas, los espacios, lenguajes y medios utilizados para la propagación de la Onda:</h3>
    <br>
    <table>
        <tr>
            <th bgcolor="#FAA803" colspan="5">1.	La propagación de los resultados de la convocatoria en nuestra institución educativa, en la comunidad y en la familia</th>
        </tr>
        <tr>
            <td>Espacios</td>
            <td>Lenguaje</td>
            <td>Medios</td>
            <td>Fecha</td>
            <td>Responsable</td>
        </tr>               
    </table>  
    <br>
    <table>
        <tr>
            <th bgcolor="#CE9AD0" colspan="5">2.	La propagación durante el recorrido de la trayectoria de indagación y una vez finalizada la investigación</th>
        </tr>
        <tr>
            <td>Espacios</td>
            <td>Lenguaje</td>
            <td>Medios</td>
            <td>Fecha</td>
            <td>Responsable</td>
        </tr>               
    </table>
    <br>
    <table>
        <tr>
            <th bgcolor="#8E8EFB" colspan="5">3.	La propagación finalizada la investigación</th>
        </tr>
        <tr>
            <td>Espacios</td>
            <td>Lenguaje</td>
            <td>Medios</td>
            <td>Fecha</td>
            <td>Responsable</td>
        </tr>               
    </table> 
    <br>
    <label>c.	Describa los medios propuestos y utilizados para la divulgación del proyecto, así como sus resultados.</label>
    <br><br>
    <h3 style="color: #000000; font-size: 12pt; alignment-adjust: central">2.	En este espacio deben escribir como se proyecta el equipo de investigación para el próximo año, teniendo en cuenta todos los aprendizajes y logros obtenidos en su experiencia investigativa con el apoyo del Programa ONDAS.</h3>
    <br>
    <h3 style="color: #000000; font-size: 14pt; alignment-adjust: central">REGISTRO DE SISTEMATIZACIÓN/ PARA EL MAESTRO ACOMPAÑANTE</h3>
    <div>
        <?php echo $url_descarga; ?><br>
        <label>Subir el Archivo de Reflexión de la Onda</label>
         <label class="lbl-button">
            <span>Seleccione aquí la imagen</span> <input type="file" name="archivo">
        </label>
    </div>
    <br>
    <div>
        <label>•  Has recorrido la travesía de el Proyecto Enjambre, ahora realiza un ensayo en el que muestres el proceso metodológico de la investigación como estrategia pedagógica para los maestros. En él debes incluir lo que sería tu fundamentación conceptual sobre este asunto y la indagación que realza y aprende el niño, la niña y el joven en el Proyecto Enjambre</label>
        <br>
        <textarea name="ensayo" placeholder="Diligencie este campo"><?php echo $ensayo; ?></textarea>
    </div>

    <input type="submit" value="Guardar">
</div>