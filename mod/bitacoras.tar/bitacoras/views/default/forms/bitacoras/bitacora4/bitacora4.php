<?php
/**
 * Formulario que muestra los datos para llenar en la bitácora4
 * @author DIEGOX_CORTEX
 */
elgg_load_js("vista_modal");
elgg_load_js("reveal2");
elgg_load_css('reveal');

$investigacion = $vars['id_inv'];
$group = $vars['id_group'];
$bit = $vars['bit'];
$actividades = $vars['actividades'];
$informacion = $vars['info'];
$owner_inv = $vars['owner_inv'];
$user = elgg_get_logged_in_user_guid();


?>



<input type="hidden" name='id_inv' value="<?php echo $investigacion; ?>">
<input type="hidden" name='id_group' value="<?php echo $group; ?>">
<input type="hidden" name='bit' value="<?php echo $bit; ?>">

<h2 class='title-legend'>
    <center><?php echo elgg_echo('pages:title3') ?></center>
</h2><br>
<div>
    <label><?php echo elgg_echo('pages:inicio') ?></label> <br>
</div>


<label><?php echo elgg_echo('pages:cronograma') ?></label> 
<?php
if ($user == $owner_inv) {
    echo "<br> <a onclick='cargarCrearActividad($bit, $investigacion, $group)' id='boton-agregar-actividad-bit4' class='elgg-button button-publicar'>Agregar Actividad</a><br><br>";
}
?>
<div id="form-crear-actividad-bit4">

</div>
  <div id="tabla-actividades-bit4">

      <?php  
        // IMPRIMO EL FORMULARIO DE ADMINISTRAR CONOGRAMA
        $vars = array('id_inv' => $investigacion, 'owner_inv' => $owner_inv, 'id_group' => $group, 'bit' => $bit, 'actividades' => $actividades);

        $content = elgg_view_form('bitacoras/bitacora4/admin_cronograma', array(), $vars);
        echo $content;
      ?>

  </div>

<div>
    <label><?php echo elgg_echo('pages:funciones') ?></label><br><br> <textarea name='funciones' style="width: 700px; height: 150px;" ><?php echo $informacion['funciones_integrantes']; ?></textarea>
</div>
<div>
    <label><?php echo elgg_echo('pages:libreta') ?></label><br><br> <textarea name='libreta' style="width: 700px; height: 150px;" ><?php echo $informacion['libreta_apuntes'] ?></textarea>
</div>
<div>
    <label><?php echo elgg_echo('pages:estudiante:rubro') ?></label><br><br> <textarea name='estudiante' style="width: 700px; height: 150px;" ><?php echo $informacion['estudiante_tesorero'] ?></textarea>
</div>
<div>
    <label><?php echo elgg_echo('pages:indagacion') ?></label><br><br> <textarea name='indagacion' style="width: 700px; height: 150px;" ><?php echo $informacion['indagacion'] ?></textarea>            
</div>
<div>
    <label><?php echo elgg_echo('pages:paso') ?></label>
</div>
<div>
    <label><?php echo elgg_echo('pages:dificultades') ?></label><br><br> <textarea name='dificultades' style="width: 700px; height: 150px;" ><?php echo $informacion['dificultades'] ?></textarea>
</div>
<div>
    <label><?php echo elgg_echo('pages:fortalezas') ?></label><br><br> <textarea name='fortalezas' style="width: 700px; height: 150px;" ><?php echo $informacion['fortalezas'] ?></textarea>
</div>
<div>
    <label><?php echo elgg_echo('pages:caracteristicas') ?></label><br><br> <textarea name='caracteristicas' style="width: 700px; height: 150px;" ><?php echo $informacion['caracteristicas'] ?></textarea>
</div>
<div>
    <label><?php echo elgg_echo('pages:importancia') ?></label><br><br> <textarea name='importancia' style="width: 700px; height: 150px;" ><?php echo $informacion['importancia'] ?></textarea>
</div>
<div>
    <label><?php echo elgg_echo('pages:preguntas') ?></label><br><br> <textarea name='preguntas' style="width: 700px; height: 150px;" ><?php echo $informacion['preguntas'] ?></textarea>
</div>
<div>
    <label><?php echo elgg_echo('pages:acompañamiento') ?></label><br><br> <textarea name='acompañamiento' style="width: 700px; height: 150px;" ><?php echo $informacion['acompañamiento'] ?></textarea>
</div>

<?php
if ($user == $owner_inv) {
    ?>
    <input type="submit" value="Guardar">
    <?php
}
?>


