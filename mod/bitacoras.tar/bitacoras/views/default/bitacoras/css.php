<?php
/**
 * Elgg Pages CSS
 *
 * @package ElggPages
 */
?>

.pages-nav.treeview ul {
	background-color: transparent;
}

.pages-nav.treeview a.selected {
	color: #555555;
}

.pages-nav.treeview .hover {
	color: #0054a7;
}