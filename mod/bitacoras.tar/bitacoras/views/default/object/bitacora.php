<?php
/**
 * Page view
 *
 * @package ElggPages
 */

echo elgg_view('object/bitacora_top', $vars);
