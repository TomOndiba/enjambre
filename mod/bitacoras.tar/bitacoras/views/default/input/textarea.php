<?php

$name=$vars['name'];
$value=$vars['value'];

$textarea = "<textarea class='text-bitacora' rows='20' cols='117' name='$name'>$value</textarea>";

echo $textarea;
