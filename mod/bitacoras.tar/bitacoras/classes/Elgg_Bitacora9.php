<?php

/**
 * Clase que representa la bitacora 9
 * @author DIEGOX_CORTEX
 */
 
class Elgg_Bitacora9 extends ElggObject {

    //put your code here

 

    function initializeAttributes() {
        parent::initializeAttributes();
        $this->attributes['subtype'] = "bitacora9";
          
        $this->attributes['comunidades'] = "";    
        $this->attributes['caracteristicas'] = "";    
        $this->attributes['organizacion'] = "";    
        
        $this->attributes['grupo_inv'] = ""; 
        $this->attributes['investigacion_nombre'] = ""; 
        $this->attributes['docente'] = ""; 
        $this->attributes['asesor'] = ""; 
        $this->attributes['institucion'] = ""; 
        $this->attributes['municipio'] = ""; 
        
        
        
        $this->attributes['access_id'] = ACCESS_PUBLIC;
    }

    function __construct($guid = null) {
        $this->initializeAttributes();
        parent::__construct($guid);
    }

    public function save() {
        
        $guid = parent::save();
        $user = elgg_get_logged_in_user_entity();
        create_metadata($guid, 'ensayo', $this->ensayo, 'text', $user->guid, ACCESS_PUBLIC);
        
        create_metadata($guid, 'grupo_inv', $this->grupo_inv, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'investigacion_nombre', $this->investigacion_nombre, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'docente', $this->docente, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'asesor', $this->asesor, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'institucion', $this->institucion, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'municipio', $this->municipio, 'text', $user->guid, ACCESS_PUBLIC);        
        
        return $guid;
       
    }

}


