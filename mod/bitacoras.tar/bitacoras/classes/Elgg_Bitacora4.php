<?php


/**
 * Clase que representa la bitacora 4
 * @author DIEGOX_CORTEX
 */
class Elgg_Bitacora4 extends ElggObject {

    //put your code here



    function initializeAttributes() {
        parent::initializeAttributes();
        $this->attributes['subtype'] = "bitacora4";
        $this->attributes['funciones_integrantes'] = "";
        $this->attributes['libreta_apuntes'] = "";
        $this->attributes['estudiante_tesorero'] = "";
        //Para el Maestro
        $this->attributes['indagacion'] = "";
        $this->attributes['dificultades'] = "";
        $this->attributes['fortalezas'] = "";
        $this->attributes['caracteristicas'] = "";
        $this->attributes['importancia'] = "";
        $this->attributes['preguntas'] = "";
        $this->attributes['acompañamiento'] = "";
        
        
        
        $this->attributes['access_id'] = ACCESS_PUBLIC;
    }

    function __construct($guid = null) {
        $this->initializeAttributes();
        parent::__construct($guid);
    }

    public function save() {
        
        $guid = parent::save();
        $user = elgg_get_logged_in_user_entity();
        create_metadata($guid, 'funciones_integrantes', $this->funciones_integrantes, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'libreta_apuntes', $this->libreta_apuntes, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'estudiante_tesorero', $this->estudiante_tesorero, 'text', $user->guid, ACCESS_PUBLIC);
        //Para el Maestro
        create_metadata($guid, 'indagacion', $this->indagacion, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'dificultades', $this->dificultades, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'fortalezas', $this->fortalezas, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'caracteristicas', $this->caracteristicas, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'importancia', $this->importancia, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'preguntas', $this->preguntas, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'acompañamiento', $this->acompañamiento, 'text', $user->guid, ACCESS_PUBLIC);
        
        return $guid;
       
    }

}
