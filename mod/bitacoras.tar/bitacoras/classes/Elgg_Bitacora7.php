<?php

/**
 * Clase que representa la bitacora 7
 * @author DIEGOX_CORTEX
 */
 
class Elgg_Bitacora7 extends ElggObject {

    //put your code here

 

    function initializeAttributes() {
        parent::initializeAttributes();
        $this->attributes['subtype'] = "bitacora7";
        
        //$this->attributes['archivo'] = "";      
        $this->attributes['aspectos'] = "";
        $this->attributes['capacidades'] = "";
        $this->attributes['cambios'] = "";
        $this->attributes['caracteristicas'] = "";     
        
        $this->attributes['grupo_inv'] = ""; 
        $this->attributes['investigacion_nombre'] = ""; 
        $this->attributes['docente'] = ""; 
        $this->attributes['asesor'] = ""; 
        $this->attributes['institucion'] = ""; 
        $this->attributes['municipio'] = ""; 
        
        
        
        $this->attributes['access_id'] = ACCESS_PUBLIC;
    }

    function __construct($guid = null) {
        $this->initializeAttributes();
        parent::__construct($guid);
    }

    public function save() {
        
        $guid = parent::save();
        $user = elgg_get_logged_in_user_entity();
        //create_metadata($guid, 'archivo', $this->archivo, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'aspectos', $this->aspectos, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'capacidades', $this->capacidades, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'cambios', $this->cambios, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'caracteristicas', $this->caracteristicas, 'text', $user->guid, ACCESS_PUBLIC);
        
        create_metadata($guid, 'grupo_inv', $this->grupo_inv, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'investigacion_nombre', $this->investigacion_nombre, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'docente', $this->docente, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'asesor', $this->asesor, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'institucion', $this->institucion, 'text', $user->guid, ACCESS_PUBLIC);
        create_metadata($guid, 'municipio', $this->municipio, 'text', $user->guid, ACCESS_PUBLIC);        
        
        return $guid;
       
    }

}

