<?php

/**
 * Action que almacena la informacion de diligenciada de la bitacora 7
 * @author DIEGOX_CORTEX
 */
$bitacora = new Elgg_Bitacora7(get_input('guid_bit'));
$aspectos = get_input('aspectos');
$capacidades = get_input('capacidades');
$cambios = get_input('cambios');
$caracteristicas = get_input('caracteristicas');


$archivo = get_input('archivo', '', false);
$name = $_FILES['archivo']['name'];
$error = $_FILES['archivo']['error'];
$tmp_name = $_FILES['archivo']['tmp_name'];
$type = $_FILES['archivo']['type'];
$other_name = "archivo";
$guid = elgg_upload_file($archivo, $id_file, $name, $error, $tmp_name, $type, $bitacora->guid, $other_name, $bitacora);


$bitacora->aspectos = $aspectos;
$bitacora->capacidades = $capacidades;
$bitacora->cambios = $cambios;
$bitacora->caracteristicas = $caracteristicas;

if($bitacora->save()){
    system_message('Se ha almacenado con éxito...', 'success');
}else{
    register_error('No se ha completado la acción, intentelo de nuevo...');
}

forward(REFERER);


