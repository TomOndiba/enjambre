<?php

/**
 * Action que almacena la informacion de diligenciada de la bitacora 8
 * @author DIEGOX_CORTEX
 */
$bitacora = new Elgg_Bitacora8(get_input('guid_bit'));

$ensayo = get_input('ensayo');


$archivo = get_input('archivo', '', false);
$name = $_FILES['archivo']['name'];
$error = $_FILES['archivo']['error'];
$tmp_name = $_FILES['archivo']['tmp_name'];
$type = $_FILES['archivo']['type'];
$other_name = "archivo";
$guid = elgg_upload_file($archivo, $id_file, $name, $error, $tmp_name, $type, $bitacora->guid, $other_name, $bitacora);


$bitacora->ensayo = $ensayo;

if($bitacora->save()){
    system_message('Se ha almacenado con éxito...', 'success');
}else{
    register_error('No se ha completado la acción, intentelo de nuevo...');
}

forward(REFERER);