<?php

/**
 * Save que almacena la informacion de la bitacora 4
 */

$investigacion = get_input('id_inv');
$gupo = get_input('id_group');
$bitacora = get_input('bit');

//CAMPOS DEL FORMULARIO
$funciones = get_input('funciones');
$libreta = get_input('libreta');
$estudiante = get_input('estudiante');
$indagacion = get_input('indagacion');
$dificultades = get_input('dificultades');
$fortalezas = get_input('fortalezas');
$caracteristicas = get_input('caracteristicas');
$importancia = get_input('importancia');
$preguntas = get_input('preguntas');
$acompañamiento = get_input('acompañamiento');

$bit_x = new Elgg_Bitacora4($bitacora);

$bit_x->funciones_integrantes = $funciones;
$bit_x->libreta_apuntes = $libreta;
$bit_x->estudiante_tesorero = $estudiante;
$bit_x->indagacion = $indagacion;
$bit_x->dificultades = $dificultades;
$bit_x->fortalezas = $fortalezas;
$bit_x->caracteristicas = $caracteristicas;
$bit_x->importancia = $importancia;
$bit_x->preguntas = $preguntas;
$bit_x->acompañamiento = $acompañamiento;

if($bit_x->save()){
    system_messages("Bitacora Alamacenada...", "success");
    forward(REFERER);
}else{
    register_error("No se pudo realizar, intente de nuevo...");
    forward(REFERER);
}

