<?php
/**
 * This view provides a hook for third parties to provide a URL shortener.
 *
 * @package Elgg
 * @subpackage Core
 */
?>